# Structural Text Segmentation of Legal Documents

---
## Disclamer
This code contains various scripts for training, generating and testing purpose with respect to the dataset. This folder consist of only scripts and not the dataset neither the pretrained models required to train or test the data.

---



## Dataset
The terms of service dataset is publicly available at https://heibox.uni-heidelberg.de/f/749127d934cb4a64929c/?dl=1. 
The dataset consist of `json` files for Terms of Services and consists about 70,000 files. 
An example file structure can be seen here: 
```
    {
            "section": "indemnification",
            "text": "Upon a request by us, you agree to defend, indemnify, and hold us and our Affiliates harmless from all liabilities, claims, and expenses, including attorneyÂ’s fees, that arise from your use or misuse of this site. We reserve the right, at our own expense, to assume the exclusive defense and control of any matter otherwise subject to indemnification by you, in which event you will cooperate with us in asserting any available defenses."
        },
  {....
  
  }
```

## compute_stats.py file
It outputs the information about the dataset

## SourceCode/BaseLine folder
This folder consists of scripts that trains and test the baseline models: Globe Vector, TF-IDF, BoW
and a file to generate the training dataset or preprocessing file.

## SourceCode/Experiment_model folder
This folder consists of scripts that trains and test the BERT and SRoBERTa models
and a file to generate the training dataset or preprocessing file and a cleaning data file.

## Requirements
The code can be run on both `python 3.7` and `python 3.8`,

For the remaining code, please refer to the requirements: 
```
pip install -r requirements.txt
```


